import React from 'react';
import {
  Button,
  Text,
  View,
  StyleSheet,
  FlatList,
  Image,
  Linking,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Version can be specified in package.json
import { StackNavigator, TabNavigator, TabBarBottom } from 'react-navigation'; // Version can be specified in package.json
import { Constants } from 'expo';

class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'Kok Zhailau',
    headerStyle: {
      backgroundColor: '#009DDC',
    },
    headerTintColor: 'white',
  };
  state = {
    images:['https://informburo.kz/img/article/697/29_main.jpg','https://tengrinews.kz/userdata/news/2017/news_327963/thumb_xm/photo_228101.jpg'],
    infText: [
      'Kok Zhailau is a wide, long plateau. There is also a pass connecting the Small Almaty and Big Almaty gorges. The height        here is about 1600 meters. Resort "Kok-Zhailau" is a unique opportunity to create the first mountain all-season resort in              Kazakhstan at the highest international standards, including it in the system of green zones and parks in Almaty. This place is        without access for road transport. The territory of Kok-Zhailau is inhabited by insects, plants, animals and birds, including          those included in the "List of rare and endangered species of animals and plants of the Republic of Kazakhstan"',
    ],
  };

  _renderItem2 = ({ item }) =>{
    return(
      <View>
        <Image
            style={{ width: 358, height: 210 }}
            source={{ uri: item }}
        />
      </View>  
    )
  }

  _renderItem = ({ item }) => {
    //console.log(item);
    return (
      <View style={{ flex: 1 }}>
        <FlatList
          horizontal={true}
          data={this.state.images}
          keyExtractor={(item, index) => index}
          renderItem={this._renderItem2}
        />
        <Text style={styles.text}>{item}</Text>
      </View>
    );
  };

  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center' }}>
        <Text style={styles.title}>What is Kok zhailau?</Text>

        <FlatList
          data={this.state.infText}
          keyExtractor={(item, index) => index}
          renderItem={this._renderItem}
        />
        <Button
          title="Start using app"
          style={styles.go}
          onPress={() => this.props.navigation.navigate('News')}
        />
      </View>
    );
  }
}

class SettingsScreen extends React.Component {
  static navigationOptions = {
    title: 'Local news',
    headerStyle: {
      backgroundColor: '#009DDC',
    },
    headerTintColor: 'white',
  };
  state = {
    news: [
      {
        title:
          'In connection with the optimization of the Kok-Zhailau project, about 100 hectares of resort land will be returned to the Ile-Alatau Park',
        imageUrl: 'https://www.kt.kz/files/content/1153658411/1153491562.jpg',
        imageUrl2: '',
        date: '22.06.2018',
        source:  'https://kt.kz/rus/society/v_svjazi_s_optimizaciej_proekta_kokzhajlau_porjadka_100_gektar_zemli_kurorta_vernut_ilealatauskomu_parku_1153658411.html',
      },

      {
        title:
          'Comments and suggestions on the Kok-Zhailau project of Almaty authorities will be accepted on the website',
        imageUrl:
          'https://bnews.kz/storage/79/79c03ea7bd4996f8c2708def04e0d616_crop_l_8_t_62_w_3255_h_1831_resize_w_525_h_.jpg',
        imageUrl2: '',
        date: '19.06.2018',
        source:
          'https://bnews.kz/ru/news/zamechaniya_i_predlozheniya_po_proektu_kokzhailyau_vlasti_almati_budut_prinimat_na_saite',
      },

      {
        title:
          'Kok-Zhailau: why did foreign experience push back the national histories of successes and failures?',
        imageUrl: 'https://informburo.kz/img/article/719/69_main.jpg',
        imageUrl2: '',
        date: '18.06.2018',
        source:
          'https://informburo.kz/stati/kok-zhaylyau-pochemu-inostrannyy-opyt-ottesnil-nacionalnye-istorii-uspehov-i-provalov-.html',
      },

      {
        title:
          'How the ecology of Almaty will change because of the construction of the resort on Kok-Zhailau',
        imageUrl:
          'https://informburo.kz/img/inner/697/88/903734_10151524693252608_956158815_o.jpg',
        imageUrl2: '',
        date: '29.04.2018',
        source:
          'https://informburo.kz/stati/kak-izmenitsya-ekologiya-almaty-iz-za-stroitelstva-kurorta-na-kok-zhaylyau.html',
      },

      {
        title: 'Is Kok-Zhailau suitable for building a world-class resort?',
        imageUrl: 'https://informburo.kz/img/article/697/29_main.jpg',
        imageUrl2: 'https://informburo.kz/img/inner/697/29/.jpg_03.jpg',
        date: '28.04.2018',
        source:
          'https://informburo.kz/stati/podhodit-li-kok-zhaylyau-dlya-stroitelstva-kurorta-mirovogo-urovnya.html',
      },

      {
        title: 'Why did everyone start talking about Kok-Zhailau again?...',
        imageUrl: 'https://sputniknews.kz/images/608/28/6082899.jpg',
        imageUrl2: '',
        date: '02.03.2018',
        source:
          'https://vlast.kz/explain/27089-pocemu-vse-snova-zagovorili-o-kok-zajlau.html',
      },
    ],
  };

  _renderItem = ({ item }) => {
    return (
      <View style={{ flex: 1 }}>
        <Image
          style={{ width: 358, height: 190 }}
          source={{ uri: item.imageUrl }}
        />
        <Text
          style={styles.text}
          onPress={
            () => {
              Linking.openURL(item.source).catch(err =>
                console.error('An error occurred', err)
              );
            } /*() => this.props.navigation.navigate('Details',{item: item})*/
          }>
          {item.title}
        </Text>
        <Text style={styles.date}>{item.date}</Text>
      </View>
    );
  };

  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center' }}>
        <FlatList
          data={this.state.news}
          keyExtractor={(item, index) => index}
          renderItem={this._renderItem}
        />
        <Button
          title="Go to Home"
          onPress={() => this.props.navigation.navigate('Info')}
        />
      </View>
    );
  }
}

class DetailsScreen extends React.Component {
  static navigationOptions = {
    title: '.ih/nk,u',
    headerStyle: {
      backgroundColor: '#009DDC',
    },
    headerTintColor: 'white',
  };
  render() {
    const { navigation } = this.props;
    
    return (
      <View style={{ flex: 1, alignItems: 'center' }}>
        <Text>fgthdsdt</Text>
      </View>
    );
  }
}

class SosScreen extends React.Component {
  static navigationOptions = {
    title: 'Sos',
    headerStyle: {
      backgroundColor: '#009DDC',
    },
    headerTintColor: 'white',
  };
  constructor(props) {
    super(props);

    this.state = {
      latitude: null,
      longitude: null,
      error: null,
      message:'',
    };
  }

  componentDidMount() {
    this.watchId = navigator.geolocation.watchPosition(
      position => {
        this.setState({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          error: null,
        });
      },
      error => this.setState({ error: error.message }),
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 1000,
        distanceFilter: 10,
      }
    );
  }

  componentWillUnmount() {
    navigator.geolocation.clearWatch(this.watchId);
  }

  sendMessage= () =>{
    this.setState({ message: ' Latitude:'+this.state.latitude+' Longitude:' +this.state.longitude})
    this.props.navigation.navigate('Info');
    alert('Operation is completed! Wait for rescuers.'+ this.state.message)
  }
  render() {
    const { navigation } = this.props;
    return (
      <View
        style={{ alignItems: 'center', backgroundColor:'#EBEDEA'}}>
        <Text style={styles.sosLabel}>Emergency help</Text>
        <Text style={styles.cooords}>Coordinates:</Text>
        <Text style={styles.lonlatt}>Latitude: {this.state.latitude}</Text>
        <Text style={styles.lonlatt}>Longitude: {this.state.longitude}</Text>  
        {this.state.error ? <Text>Error: {this.state.error}</Text> : null}
        <Text style={styles.instruction}>P.S. This is a button for calling Emergency help, in case you have LOST.{'\n'}The message about your coordinates will be immediately sent to Ministry of Emergency Situations </Text>
        <TouchableOpacity onPress={ this.sendMessage } style={styles.sosButt}>
          <Text style={styles.sosText}>Emergency help</Text>
        </TouchableOpacity>

        <Text style={styles.bottom}>nFactorial 2018</Text>
      </View>
    );
  }
}
//onPress={() => this.props.navigation.navigate('Details')}

const HomeStack = StackNavigator({
  Info: { screen: HomeScreen },
  Details: { screen: DetailsScreen },
});

const SettingsStack = StackNavigator({
  News: { screen: SettingsScreen },
  Details: { screen: DetailsScreen },
});

const SosStack = StackNavigator({
  Info: { screen: HomeScreen },
  Details: { screen: DetailsScreen },
});

export default TabNavigator(
  {
    Info: { screen: HomeStack },
    News: { screen: SettingsStack },
    Sos: { screen: SosScreen },
  },
  {
    navigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;
        if (routeName === 'Info') {
          iconName = `ios-information-circle${focused ? '' : '-outline'}`;
        } else if (routeName === 'News') {
          iconName = `ios-paper${focused ? '' : '-outline'}`;
        } else if (routeName === 'Sos'){
          iconName = `ios-compass${focused ? '' : '-outline'}`;
        }

        // You can return any component that you like here! We usually use an
        // icon component from react-native-vector-icons
        return <Ionicons name={iconName} size={25} color={tintColor} />;
      },
    }),
    tabBarComponent: TabBarBottom,
    tabBarPosition: 'bottom',
    tabBarOptions: {
      activeTintColor: '#EF7C2F',
      inactiveTintColor: 'gray',
    },
    animationEnabled: true,
    swipeEnabled: true,
  }
);

const styles = StyleSheet.create({
  /*container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
    paddingTop: Constants.statusBarHeight,
  },
  map:{
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  radius:{
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "rgba(130,4,150, 0.3)",
    position: "absolute",
    borderWidth: 1,
    borderColor: "rgba(130,4,150, 0.5)",
  },
  marker:{
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "rgba(130,4,150, 0.9)",
  },*/
  bottom:{
    marginTop:196,
  },
  sosButt:{
    marginTop:30,
    width: 355,
    height: 80,
    backgroundColor:'#009DDC',
    borderRadius: 15,
  },
  sosText:{
    color:'white',
    textAlign:'center',
    fontFamily: 'Arial',
    fontSize: 26,
    paddingTop: 19,
    fontWeight: 'bold',
  },
  instruction:{
    textAlign:'center',
    fontFamily: 'Arial',
    fontSize: 13,
    marginTop:25,
  },
  cooords:{
    fontFamily: 'Arial',
    fontSize: 26,
    fontWeight: 'bold',
    marginTop:30,
  },
  lonlatt:{
    color: '#EF7C2F',
    fontFamily: 'Arial',
    fontSize: 24,
  },
  sosLabel:{
    width: 355,
    height: 80,
    backgroundColor:'#009DDC',
    color:'white',
    paddingLeft:10,
    textAlign:'left',
    textAlignVertical:'center',
    fontSize:21,
    fontFamily: 'Arial',
    fontWeight: 'bold',

  },
  title: {
    fontFamily: 'Arial',
    fontSize: 26,
    alignSelf: 'center',
    fontWeight: 'bold',
    fontStyle: 'italic',
    color: '#EF7C2F',
  },
  go: {
    flex: 1,
    alignSelf: 'center',
    fontWeight: 'bold',
    fontFamily: 'Arial',
    fontSize: 20,
    width: 350,
    height: 60,
    backgroundColor: '#009DDC',
    textAlign: 'center',
    color: 'white',
    borderRadius: 12,
    paddingTop: 15,
  },
  text: {
    fontFamily: 'Arial',
    fontSize: 18,
    marginLeft: 10,
    marginTop: 10,
    color: '#009DDC',
    marginRight: 10,
  },
  date: {
    fontFamily: 'Arial',
    fontSize: 15,
    marginTop: 5,
    marginLeft: 10,
    fontWeight: 'bold',
    color: '#EF7C2F',
  },
});
